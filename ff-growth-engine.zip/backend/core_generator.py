
def generate_content(topic):
    return {
        "title": f"🔥 Conteúdo viral sobre {topic}",
        "post": f"Descubra novidades sobre {topic} agora.",
        "hashtags": ["#viral", "#growth", "#marketing"]
    }
