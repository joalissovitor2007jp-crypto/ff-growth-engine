
from fastapi import FastAPI
from core.generator import generate_content

app = FastAPI()

@app.get("/")
def home():
    return {"status": "FF Growth Engine Online"}

@app.get("/generate")
def generate(topic: str):
    return generate_content(topic)
