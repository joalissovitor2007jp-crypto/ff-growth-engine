
import time

while True:
    print("Gerando conteúdo automático...")
    time.sleep(3600)
